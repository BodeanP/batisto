<?php

namespace Webkul\Core\Contracts;

interface Country
{
}