<?php

namespace Webkul\Core\Contracts;

interface SubscribersList
{
}