<?php

namespace Webkul\Core\Contracts;

interface TaxMap
{
}