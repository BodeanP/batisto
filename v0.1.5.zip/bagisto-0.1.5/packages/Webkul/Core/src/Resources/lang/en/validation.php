<?php

return [
    'slug' => 'The :attribute must be valid slug.',
    'code' => 'The :attribute must be valid.',
    'decimal' => 'The :attribute must be valid.'
];