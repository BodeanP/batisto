<?php

return [
    'slug' => 'O :attribute precisa ter um slug válido.',
    'code' => 'O :attribute precisa ser válido.',
    'decimal' => 'O :attribute precisa ser válido.'
];