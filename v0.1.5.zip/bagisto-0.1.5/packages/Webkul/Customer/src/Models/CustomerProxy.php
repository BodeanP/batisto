<?php

namespace Webkul\Customer\Models;

use Konekt\Concord\Proxies\ModelProxy;

class CustomerProxy extends ModelProxy
{

}